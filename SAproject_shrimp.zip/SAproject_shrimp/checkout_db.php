<?php 
    session_start();
    include('server.php');
    
    $errors = array();

    if (isset($_POST['reg_user'])) {
        $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
        $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);
        $place = mysqli_real_escape_string($conn, $_POST['place']);
        $district = mysqli_real_escape_string($conn, $_POST['district']);
        $county = mysqli_real_escape_string($conn, $_POST['county']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        if (empty($firstname)) {
            array_push($errors, "Firstname is required");
            $_SESSION['error'] = "Firstname is required";
        }
        if (empty($lastname)) {
            array_push($errors, "Lastname is required");
            $_SESSION['error'] = "Lastname is required";
        }
        if (empty($address)) {
            array_push($errors, "Address is required");
            $_SESSION['error'] = "Address is required";
        }
        if (empty($place)) {
            array_push($errors, "Place is required");
            $_SESSION['error'] = "Place is required";
        }
        if (empty($district)) {
            array_push($errors, "District is required");
            $_SESSION['error'] = "District is required";
        }
        if (empty($county)) {
            array_push($errors, "Country is required");
            $_SESSION['error'] = "Country is required";
        }
        if (empty($password)) {
            array_push($errors, "Password is required");
            $_SESSION['error'] = "Password is required";
        }
        if (empty($phone)) {
            array_push($errors, "Phone is required");
            $_SESSION['error'] = "Phone is required";
        }
        if (empty($email)) {
            array_push($errors, "Email is required");
            $_SESSION['error'] = "Email is required";
        }
    }

?>