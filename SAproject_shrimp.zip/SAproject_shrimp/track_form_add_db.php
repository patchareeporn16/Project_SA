<?php
include('condb.php');

$a_user = $_POST['a_user'];
$a_name = $_POST['a_name'];

$sql ="INSERT INTO tbl_track
    (a_user,  a_name) 
    VALUES 
    ('$a_user', '$a_name')";
    $result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error($con));
    mysqli_close($con);
    
    if($result){
      echo "<script>";
      echo "alert('Add Succesfuly');";
      echo "window.location ='track.php'; ";
      echo "</script>";
    } else {
      
      echo "<script>";
      echo "alert('ERROR!');";
      echo "window.location ='track.php'; ";
      echo "</script>";
    }
?>