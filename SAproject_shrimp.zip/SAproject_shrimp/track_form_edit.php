<?php
//1. เชื่อมต่อ database:
include('condb.php');  //ไฟล์เชื่อมต่อกับ database ที่เราได้สร้างไว้ก่อนหน้าน้ี
$a_id = $_REQUEST["ID"];
//2. query ข้อมูลจากตาราง:
$sql = "SELECT * FROM tbl_track WHERE a_id='$a_id' ";
$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error($con));
$row = mysqli_fetch_array($result);
extract($row);
?>

<?php include('h.php');?>
<form  name="admin" action="track_form_edit_db.php" method="POST" id="admin" class="form-horizontal">
          <input type="hidden" name="a_id" value="<?php echo $a_id?>"

          <div class="form-group">
            <div class="col-sm-4" align="right"> Tracking number  </div>
            <div class="col-sm-5" align="left">
              <input  name="a_user" type="text" required class="form-control" id="a_user" placeholder="Tracking number" pattern="^[a-zA-Z0-9]+$" title="ภาษาอังกฤษหรือตัวเลขเท่านั้น" minlength="2"  />
            </div>
          </div>
          
          <div class="form-group">
            <div class="col-md-8" align="right"> ชื่อ-สกุล  </div>
            <div class="col-md-8" align="left">
              <input  name="a_name" type="text" required class="form-control" id="a_name" placeholder="ชื่อ-สกุล" />
            </div>
          </div>
          
          <div class="form-group">
            <div class="col-sm-4"> </div>
            <div class="col-sm-5" align="right">
              <button type="submit" class="btn btn-success" id="btn"> <span class="glyphicon glyphicon-saved"></span> อัพเดท  </button>      
            </div> 
          </div>
        </form>

