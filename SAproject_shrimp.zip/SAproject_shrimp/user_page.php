<?php 

    session_start();

    if (!$_SESSION['userid']) {
        header("Location: index.php");
    } else {

?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shrimp | Market</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Header Section Begin -->
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="header__top__left">
                           
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="header__top__right">  
                             <a href="index.php"><i class="fa fa-user"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-2">
                    <div class="header__logo1">
                        <a href="./index.html"><img src="img/LOGOoo.png" alt=""></a>
                    </div>
                </div>
          <!---------------------------------------------------------------------------------->
        <h1><font size=1><center>You are Member </center></font></h1>
        <h3><h1><font size=1><center> Hi, <?php echo $_SESSION['user']; ?></center></font></h3>
        <!---------------------------------------------------------------------------------->
                <div class="col-lg-6 text-center">
                    <nav class="header__menu">
                        <ul>
                            <li class="active"><a href="./index.html">Home</a></li>
                            <li><a href="./shop-grid.html">Shop</a></li> 
                            <li><a href="./tracking_number.html">tracking number</a></li> 
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-2">
                    <div class="header__cart">
                        <ul>
                            <li><a href="shoping-cart.html"><i class="fa fa-shopping-bag"></i> <span>3</span></a></li>
                        </ul>   
                    </div>
                </div>
            </div>
            <div class="humberger__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

    <!-- Hero Section Begin -->
    <section class="hero">
        <div class="container">
            <div class="row">
                <div class="col-lg-1">
                    
                </div>
                <div class="col-lg-10">
                    <div class="hero__item set-bg" data-setbg ="img/main/m.jpg">
                        <div class="hero__text">
                            <span>SHRIMP FRESH</span>
                            <h2>Shrimp <br />Market</h2>
                            <p>ศูนย์กลางการซื้อขายกุ้งที่ได้คุณภาพ</p>
                            <a href="shop-grid.html" class="primary-btn">SHOP NOW</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Categories Section Begin -->
    <section class="categories">
        <div class="container">
            <div class="row">
                <div class="categories__slider owl-carousel">
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/food/f1.jpg">
                            <h5><a href="#">กุ้งโสร่ง</a></h5>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/food/f2.jpg">
                            <h5><a href="#">กุ้งแช่น้ำปลา</a></h5>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/food/f3.jpg">
                            <h5><a href="#">กุ้งเผา</a></h5>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/food/f4.jpg">
                            <h5><a href="#">กะเพรากุ้ง</a></h5>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/food/f5.jpg">
                            <h5><a href="#">กุ้งอบวุ้นเส้น</a></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Categories Section End -->

    <!-- Footer Section Begin -->
    <footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="footer__about">
                        <div class="footer__about__logo1">
                            <a href="./index.html"><img src="img/LOGOoo.png" alt=""></a>
                        </div>
                        <ul>
                            <li>Address: 25/4 ม.10 ต.บางเตย อ.เมือง จ.ฉะเชิงเทรา 24000</li>
                            <li>Phone: 083-767-8980</li>
                            <li>Email: yosita.kcyp@gmail.com</li>
                        </ul>
                    </div>
                </div>
            </div>  
            <div class="col-lg-12">
                <div class="footer__copyright__payment"><img src="img/payment-item.png" alt=""></div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>
<!------------------------------------------------------------------------------------------------>



<?php } ?>
<!---------------------------------จบ-------------------------------------------------------------->

