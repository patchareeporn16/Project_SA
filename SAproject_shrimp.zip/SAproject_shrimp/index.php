
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
     <!-- basic -->
     <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- mobile metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1">
        <!-- site metas -->
        <meta name="keywords" content="">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- bootstrap css -->
        <link rel="stylesheet" href="css2/bootstrap.min.css">
        <!-- owl css -->
        <link rel="stylesheet" href="css2/owl.carousel.min.css">
        <!-- style css -->
        <link rel="stylesheet" href="css2/style.css">
        <!-- responsive-->
        <link rel="stylesheet" href="css2/responsive.css">
        <!-- awesome fontfamily -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

       
    

    <link rel="stylesheet" href="css2/style.css">
   
</head>
<body>
    
    

    <div class="homecontent">
        <!--  notification message -->
        <?php if (isset($_SESSION['success'])) : ?>
            <div class="success">
                <h3>
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </h3>
            </div>
        <?php endif ?>
        
    
        <!-- logged in user information -->
        <?php if (isset($_SESSION['username'])) : ?>
         <!--- <p><a href="index.php?logout='1'" style="color: red;">Log out</a></p>--->
        <?php endif ?>
    </div>
    <!------------------หน้าแรก----------------->
    <ul>
         
            <li class="button_user"><a class="button active" href="admin_or_user.php"><h3>BUY</h3></a></li>           
        </ul>
        <ul>
         
         <li class="button_user"><a class="button active" href="admin_or_user.php"><h3>SELL</h3></a></li>           
     </ul>
        <div class="slider_section">
            
                <div id="main_slider" class="carousel vert slide" data-ride="carousel" data-interval="5000">
                    <div class="carousel-inner">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="slider_cont">
                                    <h3>SHRIMP MARKET</h3>

                                    
                                    <p>สะดวกสะบาย ซื้อขายคล่อง ติดต่อเรา Shrimp Market</p>
                                               
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-8 ">
                                <img class="img-responsive" src="img/LOGOoo.png" width="1000" height="1000" alt="#" />
                            </div>
                        </div>
                    </div>
                </div>
            
        </div>
<!-- end slider section -->
</body>
</html>