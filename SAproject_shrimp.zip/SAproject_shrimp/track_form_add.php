<?php include('h.php');?>
<form  name="track" action="track_form_add_db.php" method="POST" id="track" class="form-horizontal">
          <div class="form-group">
            <div class="col-sm-4" align="right"> Tracking number  </div>
            <div class="col-sm-5" align="left">
              <input  name="a_user" type="text" required class="form-control" id="a_user" placeholder="Tracking number" pattern="^[a-zA-Z0-9]+$" title="ภาษาอังกฤษหรือตัวเลขเท่านั้น" minlength="2"  />
            </div>
          </div>
          
          
          <div class="form-group">
            <div class="col-sm-4" align="right"> ชื่อ-สกุล  </div>
            <div class="col-sm-5" align="left">
              <input  name="a_name" type="text" required class="form-control" id="a_name" placeholder="ชื่อ-สกุล" />
            </div>
          </div>
          
          <div class="form-group">
            <div class="col-sm-4"> </div>
            <div class="col-sm-5" align="right">
              <button type="submit" class="btn btn-success" id="btn"> <span class="glyphicon glyphicon-saved"></span> บันทึก  </button>      
            </div> 
          </div>
        </form>